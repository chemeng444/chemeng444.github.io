#!/usr/bin/env /home/vossj/suncat/bin/python
#above line selects special python interpreter needed to run espresso
#SBATCH -p iric 
#################
#set a job name
#SBATCH --job-name=myjob
#################
#a file for job output, you can check job progress
#SBATCH --output=myjob.out
#################
# a file for errors from the job
#SBATCH --error=myjob.err
#################
#time you think you need; default is one hour
#in minutes in this case
#SBATCH --time=2880:00
#################
#number of nodes you are requesting
#SBATCH --nodes=1
#################
#SBATCH --mem-per-cpu=4000
#################
#get emailed about job BEGIN, END, and FAIL
#SBATCH --mail-type=ALL
#################
#who to send email to; please change to your email
#SBATCH --mail-user=$USER@stanford.edu
#################
#task to run per node; each node has 16 cores
#SBATCH --ntasks-per-node=16
#################

from ase.dft.bee import BEEF_Ensemble
import numpy as np

ens = BEEF_Ensemble()

def read_beef(filename):
    energy, ensemble = ens.read(filename)
    return energy, ensemble 


# read out the energy and the ensemble of energies for each calculation
E_N2, E_ens_N2 = read_beef('folder_name/N2.bee')
E_cluster, E_ens_cluster = read_beef('folder_name/cluster.bee')
E_2N_cluster, E_ens_2N_cluster = read_beef('folder_name/2N_cluster.bee')

# compute the energy
E_2N = E_2N_cluster - E_cluster - E_N2

# computer the standard deviation (the error) from the ensembles
dE_2N = np.std(E_ens_2N_cluster - E_ens_cluster - E_ens_N2)

print "Reaction energy:", E_2N
print "Error:", dE_2N