#!/bin/tcsh /data/cees/vossj/suncat/bin/python

## your job name
#PBS -N job_name
#PBS -l nodes=1:ppn=4
#PBS -l walltime=50:00:00
#PBS -q Qhw
#PBS -V
#PBS -m e
#PBS -W x="PARTITION:sw121"

## your email address
#PBS -M sunetid@stanford.edu

## names for the job outputs
#PBS -e myjob.err
#PBS -o myjob.out

from ase.io import read
from ase.constraints import FixAtoms
from ase.vibrations import Vibrations
from espresso import espresso
from espresso.vibespresso import vibespresso
from ase.thermochemistry import HarmonicThermo

#############
## more information here: https://wiki.fysik.dtu.dk/ase/ase/thermochemistry/thermochemistry.html
#############

# rename to the name of your trajectory file
# containing the surface with adsorbates

atoms = read('ads_surface.traj')

calc = espresso(pw = 500,
                dw = 5000,
                kpts = (4, 4, 1), 
                nbands = -20,
                xc = 'BEEF-vdW', 
                convergence = {'energy':1e-5,
                               'mixing':0.1,
                               'nmix':10,
                               'maxsteps':500,
                               'diag':'david'
                                },
                spinpol = False,
                outdir = 'calcdir',
                ) 

# special calculator for the vibration calculations
calcvib = vibespresso(pw = 500,
                dw = 5000,
                kpts = (4, 4, 1), 
                nbands = -20,
                xc = 'BEEF-vdW', 
                convergence = {'energy':1e-5,
                               'mixing':0.1,
                               'nmix':10,
                               'maxsteps':500,
                               'diag':'david'
                                },
                spinpol = False,
                outdirprefix = 'vibdir',
                )  	      	      	      	   # log file                                         

atoms.set_calculator(calc)    	      	      	      	   # attach calculator to the atoms                   

energy = atoms.get_potential_energy()                      # caclulate the energy, to be used to determine G

# CHANGE TO THE ATOMS YOU NEED TO VIBRATE
# metal atoms can be assumed to be fixed
vibrateatoms=[12,13,14]	      	      	      	      	   # calculate the vibration modes of atoms #12 and #13
                                                           # change it to the atoms on your surface
atoms.set_calculator(calcvib)    	      	      	         # attach vibrations calculator to the atoms                   

# Calculate vibrations                                                                                        
vib = Vibrations(atoms,indices=vibrateatoms,delta=0.03)    # define a vibration calculation                   
vib.run()     	      	      	      	      	      	   # run the vibration calculation                    
vib.summary(method='standard')	      	      	      	   # summarize the calculated results                 

for mode in range(len(vibrateatoms)*3):                    # Make trajectory files to visualize the modes.    
    vib.write_mode(mode)

# Calculate free energy
vibenergies=vib.get_energies()
vibenergies[:]=[vib for vib in vibenergies if not isinstance(vib,complex)]  # only take the real modes
gibbs = HarmonicThermo(vib_energies = vibenergies, electronicenergy = energy)

# At 300K and 101325 Pa
# change for your operating conditions 
freeenergy = gibbs.get_gibbs_energy(300,101325)

f=open('out.energy','w')
f.write('Potential energy: '+str(energy)+'\n'+'Free energy: '+str(freeenergy)+'\n')
f.close
