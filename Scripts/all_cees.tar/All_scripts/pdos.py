#!/usr/bin/env /home/vossj/suncat/bin/python

## your job name
#PBS -N job_name
#PBS -l nodes=1:ppn=4
#PBS -l walltime=20:00:00
#PBS -q Q19
#PBS -V
#PBS -m e
#PBS -W x="PARTITION:sw121"

## your email address
#PBS -M sunetid@stanford.edu

## names for the job outputs
#PBS -e myjob.err
#PBS -o myjob.out

import cPickle as pickle
from ase import io
from espresso import espresso


atoms = io.read('relaxed.traj')
atoms.set_pbc((True,True,True))

# make sure these settings are consistent with what you have been using!
calc=espresso(pw=500,
              dw=5000,
              kpts=(4,4,1),
              nbands=-20,
              sigma=0.1,
              xc='BEEF-vdW',
              outdir='pdos',
              convergence = {'mixing':0.1,'maxsteps':200},
              output = {'avoidio':True,'removewf':True,'wf_collect':False},
              )

atoms.set_calculator(calc)
energy = atoms.get_potential_energy()
print 'energy:',energy


dos = calc.calc_pdos(nscf=True, kpts=(4,4,1), tetrahedra=False, sigma=0.2)

#save dos and pdos into pickle file
f = open('out_dos.pickle', 'w')
pickle.dump(dos, f)
f.close()